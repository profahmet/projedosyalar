#include <16F88.h>
#device ADC=10
#FUSES INTRC_IO, NOPUT, NOMCLR, NOBROWNOUT, NOLVP, NOCPD, NOWRT, NOPROTECT, NOFCMEN, NOIESO
#use delay(internal=4MHz)
#define LCD_ENABLE_PIN PIN_B3
#define LCD_RS_PIN PIN_B1
#define LCD_RW_PIN PIN_B2
#define LCD_DATA4 PIN_B4
#define LCD_DATA5 PIN_B5
#define LCD_DATA6 PIN_B6
#define LCD_DATA7 PIN_B7
#include <lcd.c>

int16 ADC0;
float volt,basinc;

void main() {
   setup_adc_ports(sAN0);
   setup_adc(ADC_CLOCK_INTERNAL);
   lcd_init();
   delay_ms(250);
   
   while(TRUE){
   set_adc_channel(0);
   delay_ms(10);
   ADC0=read_adc();
   volt=((float)ADC0*5)/1023;
   basinc=((volt+5*0.085)/(5*0.0090));
   lcd_gotoxy(1,1);
   printf(lcd_putc," VOLTAJ=%1.1fv ",volt);
   lcd_gotoxy(1,2);
   printf(lcd_putc," BASINC=%1.1fkpa ",basinc);
   
   delay_ms(250);
   }

}
