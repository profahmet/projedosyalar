#include <16F886.h>
#define VREF_A2   0x40
#device adc=10
#FUSES NOWDT, INTRC_IO, MCLR, NOBROWNOUT, NOIESO, NOFCMEN, NOLVP, BORV21, NOPUT, NOPROTECT, NOCPD
#use delay(clock=8000000)
#include <1602_LCD.C>


int16 ADC0, ADC1, TOPLAM ;
FLOAT VOLT ;

void main() {
   setup_oscillator(OSC_8MHZ|OSC_INTRC);
   setup_adc_ports(sAN0);
   setup_adc(ADC_CLOCK_DIV_2);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(VREF_LOW|12|VREF_A2);
   set_tris_b(0x00);
   output_b(0x00);
   lcd_init();

   while(TRUE){
   setup_adc_ports(sAN0|VSS_VREF);
   set_adc_channel(0);
   delay_ms(10);
   ADC0=read_adc(ADC_START_AND_READ); 
   
   setup_adc_ports(sAN0|VREF_VDD);
   set_adc_channel(0);
   delay_ms(10);
   ADC1=read_adc(ADC_START_AND_READ);
   
   TOPLAM=ADC0+ADC1;
   VOLT=TOPLAM;
   VOLT=(VOLT * 5 )/2046;
   
   lcd_gotoxy(1,1);
   printf(lcd_putc," ADC=%lu ",TOPLAM,);
   lcd_gotoxy(2,1);
   printf(lcd_putc," VOLT=%1.3f ",VOLT,);
   //printf(lcd_putc," ADC=%lu   \n VOLT=%1.3f   ",TOPLAM,VOLT,);
   
   delay_ms(250); 
   
   
   }

}
